ETL_BK is a 120mm X 43.1mm 4-layer board of 1.6mm thick.
PCB stack up is JLC2313 with green solder mask.

Gerber files include:
ETL_BK.gts Top solder mask
ETL_BK.gtl top layer signal
ETL_BK.gp1 layer 1 plane
ETL_BK.gp2 layer 2 plane
ETL_BK.gbl bottom layer signal
ETL_BK.gbs botton solder mask
ETL_BK.m14 fab drawing

ETL_BK.txt NC drill file
All hole sizes are drill size, not finished sizes.


