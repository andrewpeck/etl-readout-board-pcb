Zip file includes
ReadMe.txt	this file
BOM folder	BOM in excel
Gerber folder	Gerber files. *.M14 is board dimension
NC Drill folder Drill file
Pick Place folder pick and place file

PCB material is 1.0mm thick two sided FR4
copper thickness is 1/2 Oz
surface treatment is immersion gold.
