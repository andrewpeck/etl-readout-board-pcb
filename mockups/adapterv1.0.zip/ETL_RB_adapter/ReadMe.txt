ETL_RB_adapter is a 120mm X 43.1mm 4-layer board of 1.6mm thick.
PCB stackup is JLC7628 with green solder mask.

Gerber files include:
adapterv1.0.gto top silk screen
adapterv1.0.gts Top solder mask
adapterv1.0.gtp Top paste mask
adapterv1.0.gtl top layer signal
adapterv1.0.gp1 layer 1 plane
adapterv1.0.gp2 layer 2 plane
adapterv1.0.gbl bottom layer signal
adapterv1.0.gbs botton solder mask
adapterv1.0.gbp botton paste mask
adapterv1.0.gbo botton silk screen
adapterv1.0.m14 fab drawing

adapter.txt NC drill file
All hole sizes are drill size, not finished sizes.


